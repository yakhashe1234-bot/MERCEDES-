package com.carscreen.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.webkit.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    lateinit var web: WebView
    var tts: TextToSpeech? = null
    var cb: ValueCallback<Array<Uri>>? = null
    var gps = false
    var fresh = false

    inner class Bridge {
        @JavascriptInterface fun setVolume(p: Int) {
            val a = getSystemService(AUDIO_SERVICE) as AudioManager
            a.setStreamVolume(AudioManager.STREAM_MUSIC, a.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100, 0)
        }
        @JavascriptInterface fun getVolume(): Int {
            val a = getSystemService(AUDIO_SERVICE) as AudioManager
            return a.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fresh = b == null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true; allowUniversalAccessFromFileURLs = true
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, f: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = f
                startActivityForResult(p.createIntent(), 2); return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Car")
        web.loadUrl("file:///android_asset/index.html")
        tts = TextToSpeech(this, this)
        startGps()
    }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS && fresh) {
            tts?.language = Locale.US
            tts?.speak("Welcome to Mercedes Benz", TextToSpeech.QUEUE_FLUSH, null, "w")
        }
    }

    fun startGps() {
        if (gps) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, object : LocationListener {
                override fun onLocationChanged(l: Location) {
                    web.post { web.evaluateJavascript("onLoc(${l.latitude},${l.longitude},${l.speed},${l.bearing})", null) }
                }
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
                @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
            })
            gps = true
        } catch (e: SecurityException) {}
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { startGps() }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        if (req == 2) { cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); cb = null }
    }

    override fun onBackPressed() {}
}
